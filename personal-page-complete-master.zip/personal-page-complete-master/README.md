## Personal site

https://natashapetrus.com/

#### :fire: Generated with:
* [Gulp](https://gulpjs.com/)
* [Jekyll](https://jekyllrb.com/)
  * [jekyll-assets](https://github.com/envygeeks/jekyll-assets)
  * [jekyll-minibundle](https://github.com/tkareine/jekyll-minibundle)
  * [jekyll-sitemap](https://github.com/jekyll/jekyll-sitemap)
  * [jekyll-last-modified-at](https://github.com/gjtorikian/jekyll-last-modified-at)
* [uglifier](https://github.com/lautis/uglifier)
* [sass](https://github.com/sass/ruby-sass)

#### :star: Credits:
* [Colorlib](https://colorlib.com) (base template)
* [Toptal Designers](https://www.toptal.com/designers/subtlepatterns/) (background image)
* [Font Awesome](https://fontawesome.com/) (icon set)
* [Font Squirrel](https://www.fontsquirrel.com/) (font cross-browser compatibility)

#### :heart: Quick links:
* [Facebook](http://fb.natashapetrus.com)
* [Instagram](http://ig.natashapetrus.com)
* [LinkedIn](http://linkedin.natashapetrus.com)
* [GitHub](http://github.natashapetrus.com)
* [E-mail](mailto:hello@natashapetrus.com)
